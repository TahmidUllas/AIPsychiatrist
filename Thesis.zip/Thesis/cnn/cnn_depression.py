import logging
from typing import Dict, List, Union

import pandas
from ludwig import LudwigModel


def get_model_definitions() -> Dict[str, Union[List[Dict[str, str]], Dict[str, int]]]:
    model_definition = {
        "input_features": [{"name": f"Q{i}", "type": "numerical", "encoder": "parallel_cnn"} for i in range(1, 31)],
        "output_features": [
            {
                "name": "Prediction",
                "type": "category"
            }
        ],
        "training": {
            "epochs": 45
        }
    }
    return model_definition


def train():
    model = LudwigModel(get_model_definitions(), logging_level=logging.INFO)
    print("Loading CSV to Pandas Dataframe...")
    df = pandas.read_csv("../dataset/depression/depression_data_extra_large.csv")
    print("Starting training...")
    model.train(data_df=df, logging_level=logging.INFO, output_directory="ludwig_model_depression")
    print("Running tests...")
    res = model.predict(data_df=pandas.read_csv("../dataset/test/test_large_depression.csv"),
                        logging_level=logging.DEBUG)
    print("Saving test result...")
    res.to_csv("../result/depression_result.csv")
    model.save(save_path="../cnn_model_depression")
    model.close()
    print("DONE!")


def test():
    model = LudwigModel.load(model_dir="../cnn_model_depression", logging_level=logging.ERROR)
    print("Running tests...")
    res = model.predict(data_df=pandas.read_csv("../dataset/test/test_large_depression.csv"),
                        logging_level=logging.ERROR)
    print("Saving test result...")
    res.to_csv("../result/depression_result_cnn.csv")
    model.close()


if __name__ == '__main__':
    train()
    test()
