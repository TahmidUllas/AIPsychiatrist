import json

from matplotlib import pyplot

JSON_STAT_FILE = "ludwig_model_anxiety/_run_0/training_statistics.json"

data = json.load(open(JSON_STAT_FILE, "r"))

description = {
    "training": {
        "batch_size": 128,
        "bucketing_field": None,
        "decay": False,
        "decay_rate": 0.96,
        "decay_steps": 10000,
        "dropout_rate": 0.0,
        "early_stop": 3,
        "epochs": 45,
        "gradient_clipping": None,
        "increase_batch_size_on_plateau": 0,
        "increase_batch_size_on_plateau_max": 512,
        "increase_batch_size_on_plateau_patience": 5,
        "increase_batch_size_on_plateau_rate": 2,
        "learning_rate": 0.001,
        "learning_rate_warmup_epochs": 5,
        "optimizer": {
            "beta1": 0.9,
            "beta2": 0.999,
            "epsilon": 1e-08,
            "type": "adam"
        },
        "reduce_learning_rate_on_plateau": 0,
        "reduce_learning_rate_on_plateau_patience": 5,
        "reduce_learning_rate_on_plateau_rate": 0.5,
        "regularization_lambda": 0,
        "regularizer": "l2",
        "staircase": False,
        "validation_field": "combined",
        "validation_measure": "loss"
    }
}
print("Evaluation CNN\nParameters:")
for key in description.get("training"):
    temp = " ".join([s.upper() for s in key.split("_")])
    print(f"\t{temp}: {description['training'][key]}")

training, testing, validation = ("Training", data["train"]["combined"]["accuracy"]), (
    "Testing", data["test"]["combined"]["accuracy"]), \
                                ("Validation", data["validation"]["combined"]["accuracy"])

for name, accuracy in [training, validation, testing]:
    pyplot.plot(accuracy)
    pyplot.suptitle(f"Anxiety | {name} Accuracy")
    pyplot.ylabel("Accuracy")
    pyplot.xlabel("Epoch")
    pyplot.show()
