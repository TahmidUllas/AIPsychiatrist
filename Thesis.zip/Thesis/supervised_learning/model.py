import warnings

import pandas
from sklearn import model_selection, preprocessing
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.svm import SVC

warnings.filterwarnings("ignore")

ACCURACY = []
PRECISION_WEIGHTED = []
RECALL_WEIGHTED = []
F1_WEIGHTED = []


class Dataset:
    dataset: str = "../dataset/anxiety/anxiety_data_tiny.csv"

    def __init__(self, **kwargs):
        if "dataset" in kwargs:
            self.dataset = kwargs.get("dataset")
        data = pandas.read_csv(self.dataset)
        self.dataframe = pandas.DataFrame(data)

        label_encoder = preprocessing.LabelEncoder()
        enc = label_encoder.fit(self.dataframe['Prediction'])
        self.dataframe['Prediction'] = enc.transform(
            self.dataframe['Prediction'])
        dta = pandas.DataFrame(self.dataframe,
                               columns="Q1 Q2 Q3 Q4 Q5 Q6 Q7 Q8 Q9 Q10 Q11 Q12 Q13 Q14 Q15 Q16 Q17 Q18 Q19 Q20 Q21 Q22 Q23 Q24 Q25 Q26 Q27 Q28 Q29 Q30".split(
                                   " "))
        outcome = self.dataframe['Prediction']

        self.train_x, self.x_test, self.train_y, self.y_test = model_selection.train_test_split(dta, outcome,
                                                                                                test_size=0.2)


class Model:
    algorithm: str
    dataset = Dataset = Dataset(dataset="../dataset/depression/depression_data_large.csv")

    def __init__(self, algorithm: str):
        self.algorithm = algorithm
        self.dataset = Dataset()

    def __evaluate__(self, model):
        kfold = model_selection.KFold(n_splits=10, random_state=7)
        self.accuracy = model_selection.cross_val_score(model, self.dataset.train_x, self.dataset.train_y, cv=kfold,
                                                        scoring='accuracy')
        y_predict = model_selection.cross_val_predict(model, self.dataset.train_x, self.dataset.train_y, cv=kfold)
        self.precision_weighted = model_selection.cross_val_score(model, self.dataset.train_x, self.dataset.train_y,
                                                                  cv=kfold, scoring='precision_weighted')
        self.recall_weighted = model_selection.cross_val_score(model, self.dataset.train_x, self.dataset.train_y,
                                                               cv=kfold, scoring='recall_weighted')
        self.f1_weighted = model_selection.cross_val_score(model, self.dataset.train_x, self.dataset.train_y,
                                                           cv=kfold, scoring='f1_weighted')

        ACCURACY.append(self.accuracy)
        PRECISION_WEIGHTED.append(self.precision_weighted)
        RECALL_WEIGHTED.append(self.recall_weighted)
        F1_WEIGHTED.append(self.f1_weighted)

        print("=" * 100)
        msg = "%s: Accuracy -> %f | Standard Deviation -> %f" % (
            self.algorithm, self.accuracy.mean(), self.accuracy.std())
        print(msg)

        msg = "%s: Precision Weighted -> %f | Standard Deviation -> %f" % (
            self.algorithm, self.precision_weighted.mean(), self.precision_weighted.std())
        print(msg)

        msg = "%s: Recall Weighted -> %f | Standard Deviation -> %f" % (
            self.algorithm, self.recall_weighted.mean(), self.recall_weighted.std())
        print(msg)

        msg = "%s: F1 Weighted -> %f | Standard Deviation -> %f" % (
            self.algorithm, self.f1_weighted.mean(), self.f1_weighted.std())
        print(msg)
        print("=" * 100)


class SVM(Model):
    kernel: str = "poly"
    degree: int = 3

    def __init__(self):
        super(SVM, self).__init__("SVM")
        self.obj = SVC(kernel=self.kernel, degree=self.degree)

    def evaluate(self):
        params = [
            f"Penalty parameter C of the error term: {self.obj.C}",
            f"Kernel: {self.obj.kernel}",
            f"Degree: {self.obj.degree}",
            f"Gamma: {self.obj.gamma}",
            f"Independent term in kernel function: {self.obj.coef0}",
            f"Shrinking: {self.obj.shrinking}",
            f"Probability: {self.obj.probability}",
            f"Tolerance for stopping criterion: {self.obj.tol}",
            f"Cache Size: {self.obj.cache_size}",
            f"Max Iteration: {self.obj.max_iter}",
            f"Decision Function Shape: {self.obj.decision_function_shape}",
            f"Random State: {self.obj.random_state}"
        ]
        print(f"Evaluating {self.algorithm} \nParameters:\n\t" + "\n\t".join(params))
        self.__evaluate__(self.obj)


class LDA(Model):

    def __init__(self):
        super(LDA, self).__init__("LDA")
        self.obj = LinearDiscriminantAnalysis()

    def evaluate(self):
        params = [
            f"Solver: {self.obj.solver}",
            f"Shirkage: {self.obj.shrinkage}",
            f"Priors: {self.obj.priors}",
            f"NComponents: {self.obj.n_components}",
            f"Store Covariance: {self.obj.store_covariance}",
            f"Tol: {self.obj.tol}"
        ]
        print(f"Evaluating {self.algorithm} for Depression analysis\nParameters:\n\t" + "\n\t".join(params))
        self.__evaluate__(self.obj)
