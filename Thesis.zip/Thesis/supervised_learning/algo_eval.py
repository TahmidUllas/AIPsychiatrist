from supervised_learning.model import LDA, SVM


def plot():
    from matplotlib import pyplot as plt
    from supervised_learning.model import ACCURACY, PRECISION_WEIGHTED, RECALL_WEIGHTED, F1_WEIGHTED

    fig = plt.figure()
    fig.suptitle('Algorithm Comparison based on Accuracy')
    ax = fig.add_subplot(111)
    plt.boxplot(ACCURACY)
    plt.show()

    # Compare Algorithms based on Precision Weight
    fig = plt.figure()
    fig.suptitle('Algorithm Comparison based on Precision Weight')
    ax = fig.add_subplot(111)
    plt.boxplot(PRECISION_WEIGHTED)
    plt.show()

    # Compare Algorithms based on F1 Weight
    fig = plt.figure()
    fig.suptitle('Algorithm Comparison based on Recall Weight')
    ax = fig.add_subplot(111)
    plt.boxplot(RECALL_WEIGHTED)
    plt.show()

    # Compare Algorithms based on F1 Weight
    fig = plt.figure()
    fig.suptitle('Algorithm Comparison based on F1 Weight')
    ax = fig.add_subplot(111)
    plt.boxplot(F1_WEIGHTED)
    plt.show()


def main():
    lda = LDA()
    svm = SVM()

    lda.evaluate()
    svm.evaluate()
    plot()


if __name__ == '__main__':
    main()
